TaskGraph project is implemented using VS 2015. 
All code is standart C++ 14 so it should be portable to any modern compiler. 
Some minor fixes may be needed.

1. Should be scalable to the number of cores for the current system. 

Task graph start some threads at start and feeds them with tasks. 
They can be set up according the number of cores.

2. Should support static & dynamic tasks

- Static task � task which is known in advance and usually connected with specific system i.e. AI, Graphic, Physics, etc..

Task grapth can define static tasks and set dependencies between them, 
when task copletes it's child is executed.

- Dynamic task � not known in advance, can be scheduled from other tasks and/or systems

You can use another task graph inside a task and block the thread while inner tasks are completed.
Check Test1 for dynamic tasks example. 
Capturung task graph inside other tasks and adding tasks yelds undefined behavior ( multithreaded adding ot tasks is not not protected)
This is because Task Graph is intended to run in single thread that manages oghers.


3. Should be implemented using lockless structures whenever possible

4. Should support affinity & number of cores for every task

Every task has defined affinity, parralel tasks can specify number of threads they are executed.
Parralel tasks are limited by the number of worker threads defined by the TaskGraph scheduler.

5. Should support task dependencies

Task dependencies are supported using chained tasks functionality.

More complex task dependencies can be implemented using custom strategies: 
Foe example Parallel reduce task which waits for number of threads to be done before executed (see Test3)

6. Should have minimal runtime overhead for both CPU & memory

7. Can be based on current std functionality for threads, lockless, async, futures, etc.

8. Can use the modern C++11(and beyond) features like lambda functions especially for dynamic tasks

9. Use the task scheduler for any multithread capable tasks like image processing for demonstrating the system

See Test3 and Test5. Image processing code for both tests is borrowed from Pro_TBB book.

10. Bonus 1: Implement task stealing - the task threads should be able to steal work from other task threads if they have nothing to process

When thread goes out of tasks it tris to steal some tasks from other threads.
Can be seen in Test3.

11. Bonus 2 : Print the current task graph which shows how the tasks are divided, what are the dependencies between them, etc.

PrintTasksExecution prints the order of execution of tasks.
Other information can be easily printed if needed ( like tasks execution order by thread etc.).

12. Bonus 3 : Use the task scheduler for multithread generation of command buffers for DX11/DX12. If implemented, the candidate could skip point 9 as they are interchangeable.
